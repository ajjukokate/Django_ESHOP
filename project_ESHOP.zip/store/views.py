from django.shortcuts import render, redirect,HttpResponseRedirect
from .models.category import Category
from .models.customer import Customer
from .models.product import Product
from .models.orders import Order
from django.contrib import messages
from django.contrib.auth.hashers import make_password,check_password
from django.views import View
from .middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator





# Create your views here.

# class base view
class Index(View):

    def post(self,request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)

                    else:
                        cart[product] = quantity - 1

                else:
                    cart[product] = quantity + 1

            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart

        return redirect('index')

    def get(self,request):

        cart = request.session.get('cart')
        if not cart:
            request.session.cart = {}

        products = None
        categories = Category.get_all_categories()  # function define in product.py model
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.get_all_products_by_category_id(categoryID)
        else:
            products = Product.get_all_products()

        template_name = 'index.html'
        context = {'products': products, 'categories': categories}
        return render(request, template_name, context)


# function base view
def signupview(request):
    if request.method == 'GET':
        template_name = 'signup.html'
        context = {}
        return render(request, template_name, context)

    else:
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('mobileno')
        email = postData.get('email')
        password = postData.get('password')
        confirmpassword = postData.get('confirmpassword')



        # validators

        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email,
            }

        error_message = None

        if not first_name:
            error_message = "First Name Required !!"
        elif len(first_name) > 20:
            error_message = "First Name Not More Than 20 Character !!"
        elif not last_name:
            error_message = "Last Name Required !!"
        elif len(last_name) > 20:
            error_message = "Last Name Not More Than 20 Character !!"
        elif not phone:
            error_message = "Mobile Number Required !!"
        elif len(phone) < 10 or len(phone) > 10:
            error_message = "Mobile Number Must Be 10 Numbers !!"
        elif Customer.objects.filter(phone=phone).exists():
            error_message = "Mobile No. Already Exists !!"
        elif not email:
            error_message = "Email Address Required !!"
        elif Customer.objects.filter(email=email).exists():
            error_message = "Email Id Already Exists !!"
        elif not password:
            error_message = "Password Required !!"
        elif len(password) < 8 or len(password) > 15:
            error_message = "Password Between 8 To 15 Characters !!"
        elif password != confirmpassword:
            error_message = "Password Not Same !!"

        # saving

        if not error_message:
            customer = Customer(first_name=first_name,
                                last_name=last_name,
                                phone=phone,
                                email=email,
                                password=password,
                                confirmpassword=confirmpassword)
            # password hashing

            customer.password = make_password(customer.password)
            customer.confirmpassword = make_password(customer.confirmpassword)

            customer.save()
            msg = "Your Registration Successfully Completed !!"
            template_name = 'signup.html'
            context={'msg':msg}
            return render(request,template_name,context)

        else:
            template_name = 'signup.html'
            context = {'error': error_message, 'values': value}
            return render(request, template_name, context)



# class base view

class Login(View):

    return_url = None

    def get(self,request):
        Login.return_url = request.GET.get('return_url')
        template_name = 'login.html'
        context = {}
        return render(request, template_name, context)

    def post(self,request):
        if request.method == 'POST':
            email = request.POST.get('email')
            password = request.POST.get('password')

            customers = Customer.objects.filter(email=email)

            value = {
                'email': email,
                'password': password,
            }

            error_message = None

            if not email:
                error_message = "Email Address Required !!"

            elif not password:
                error_message = "Password Required !!"

            if not error_message:

                if customers:
                    for customer in customers:
                        if check_password(password, customer.password):
                            request.session['customer_id'] = customer.id
                            request.session['email'] = customer.email
                            request.session['fname'] = customer.first_name

                            if Login.return_url:
                                return HttpResponseRedirect(Login.return_url)
                            else:
                                Login.return_url = None
                                return redirect('index')


                        else:
                            messages.error(request, "Email or Password invalid !!")
                            return redirect('login')

                else:
                    messages.error(request, "Email Address Not Registered With Us !!")
                    return redirect('login')

            else:
                template_name = 'login.html'
                context = {'error': error_message,'values': value}
                return render(request, template_name, context)


def logoutview(request):
    request.session.clear()
    return redirect('login')

class Cart(View):

    def get(self,request):

        ids = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(ids)

        template_name = 'cart.html'
        context = {'products':products}
        return render(request, template_name,context)

    def post(self,request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)

                    else:
                        cart[product] = quantity - 1

                else:
                    cart[product] = quantity + 1

            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart

        return redirect('cart')


class Checkout(View):

    def post(self,request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address,phone,customer,cart,products)

        for product in products:
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          name=product.name,
                          address=address,
                          phone=phone,
                          quantity=cart.get(str(product.id)))


            order.save()
            request.session['cart'] = {}

        return redirect('cart')

class OrderView(View):


    def get(self, request):
        customer = request.session.get('customer_id')
        orders = Order.get_orders_by_customer(customer)
        print(orders)
        template_name = 'orders.html'
        context = {'orders': orders}
        return render(request, template_name, context)










# function base view

# def loginview(request):
#     if request.method == 'POST':
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#
#         customers = Customer.objects.filter(email=email)
#
#         for customer in customers:
#             if customer.email == email and check_password(password,customer.password):
#                 return redirect('index')
#             else:
#                 messages.error(request,"Email or Password invalid !!")
#                 return redirect('login')
#
#     template_name = 'login.html'
#     context = {}
#     return render(request, template_name, context)


