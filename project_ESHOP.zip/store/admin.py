from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order

# Register your models here.

class ProductAdmin(admin.ModelAdmin):
    list_display = ['id','name','price','category','description','image']
admin.site.register(Product,ProductAdmin)


class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id','name']
admin.site.register(Category,CategoryAdmin)

class CustomerAdmin(admin.ModelAdmin):
    list_display = ['id','first_name','last_name','phone','email','password','confirmpassword']
admin.site.register(Customer,CustomerAdmin)

class OrderAdmin(admin.ModelAdmin):
    list_display = ['id','product','customer','name','address','phone','status','quantity','price','date']
admin.site.register(Order,OrderAdmin)