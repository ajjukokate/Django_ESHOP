from django.urls import path
from .views import Index,signupview,Login,logoutview,Cart,Checkout,OrderView
from .middlewares.auth import auth_middleware

urlpatterns=[
    path('iv/',Index.as_view(),name='index'),
    path('suv/',signupview,name='signup'),
    path('liv/',Login.as_view(),name='login'),
    path('lov/',logoutview,name='logout'),
    path('cv/',Cart.as_view(),name='cart'),
    path('co/',Checkout.as_view(),name='checkout'),
    path('ov/',auth_middleware(OrderView.as_view()),name='order'),

]